<div id="wow-leftcol">
	<p style="color: #43cb83; font-size:36px; margin-top:0px; padding-top:0px;">ADDITIONAL OPTIONS IN PRO VERSION</p>
</div>
<div id="wow-rightcol">
	<a href="https://wow-estore.com/en/wow-side-menus-pro/" target="_blank" class="wow-btn">GET PRO VERSION</a>
</div>
<div class="wow-admin-col" style="font-size:18px;">
	
	<div class="wow-admin-col-12">
		<ul>
			<li>Unlimited amount of menu items</li>
			<li>Powerful styling</li>
			<li>Custom icons</li>
			<li>Powerful page-level placement</li>
			<li>Built-in social share buttons</li>
			<li>Built-in print & back-to-top buttons</li>
			<li>Show menu items depending on language (allows creating multi-language side menues)</li>
			<li>Show menu item depending on user (for all users, only for logged-in users, only for not logged-in users)</li>
			<li><a href="https://wow-estore.com/en/wow-side-menus-pro/" target="_blank">And more...</a></li>
		</ul>
	</div>	
</div>




<p style="color: #43cb83; font-size:36px; margin-top:0px; padding-top:0px;">RATE PLUGIN &amp; GET A 30% DISCOUNT!!!</p>
<div style="float: left;"><img src="<?php echo plugin_dir_url( __FILE__ ); ?>img/banner.png" alt="" width="350" /></div>
<div style="padding-left: 20px; padding-right:20px; float: left; font-family: Tahoma; width: 60%; font-size:18px;">
	
	<p style="font-size:18px;">Sweet deal for you. Spend 1 minute, rate our free plugin at Wordpress.org and get a third off the Wow version of your choice.</p>
	<ol>
		<li style="margin-bottom:15px;">Leave a 5 star rating and add a comment at the <a href="https://wordpress.org/support/plugin/mwp-side-menu/reviews/" target="_blank" style="color: #43cb83;">plugin's wordpress.org page</a></li>
		<li style="margin-bottom:15px;">Send us an email to wow@wow-company.com with the subject 'Discount for rating', with the nickname you used to leave the rating.</li>
		<li style="margin-bottom:20px;">We will send you back a 30% discount code that you can use to purchase any Wow version at <a href="https://wow-estore.com" target="_blank" style="color: #43cb83;">wow-estore.com</a></li>
	</ol>
</div>
