# Contributing to User Access Manager

* The coding style must PSR-2
* The unit test code coverage must be 100% expect for the views and the wrappers
* The _Humbug Mutation Score Indicator_ must be 100% (all mutants must be killed)