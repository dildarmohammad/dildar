<?php

namespace UserAccessManager\Setup\Database;

/**
 * Class MissingColumnsException
 *
 * @package UserAccessManager\Setup\Database
 */
class MissingColumnsException extends \Exception
{

}
