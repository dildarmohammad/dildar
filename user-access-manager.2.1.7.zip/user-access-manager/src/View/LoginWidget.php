<?php
/**
 * @var \UserAccessManager\Widget\LoginWidget $controller
 */
?>
<section class="widget">
    <?php
    include 'Login/LoginForm.php';
    ?>
</section>